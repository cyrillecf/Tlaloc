package com.aistos.tlaloc.data;

public interface Dto {
	
	
}
